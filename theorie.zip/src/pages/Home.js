import NavigationBar from "../components/NavigationBar";
import { Grid } from "@mui/material";
import StyleJS from "../StyleJS.css";

export default function Home() {
  return (
    <>
      <NavigationBar activePage="Home" />
      <article>
        <h1>La théorie des jeux</h1>
          <p>Issue des mathématiques dans les années 1920, la théorie des jeux permet de prévoir le comportement des agents économiques, en faisant l’hypothèse que tout agent effectue toujours un choix rationnel visant à maximiser ses gains et à minimiser ses pertes.</p>
          <p>Elle offre un cadre formel à des questions de stratégies dans des situations d’interactions entre plusieurs agents. Elle s’intéresse notamment aux situations dans lesquelles les décisions prises par un agent ont un impact sur la manière dont les autres agents agissent et réagissent.
          Par exemple, une entreprise a-t-elle intérêt à baisser le prix de vente de son produit pour augmenter ses ventes ? Pas forcément… L’entreprise doit, ainsi, anticiper la réaction de ses concurrents, qui pourraient suivre la même stratégie de réduction du prix de vente. Sans anticipation
          de la contre-offensive commerciale des autres entreprises opérant sur le marché, le consommateur sera le seul gagnant (il bénéficiera de la baisse des prix).</p>
          <p>Toute la question est de savoir s’il est possible de prévoir les stratégies des différents protagonistes.</p>
        
        <h1>L'équilibre de Nash</h1>
          <p>Nash soutient sa thèse sur les jeux non-coopératifs en 1950. Dans cette catégorie de jeux, les agents ont des buts opposés. Les jeux coopératifs, quant à eux, visent à trouver la meilleure solution en faisant coopérer plusieurs joueurs.</p> 
          <p>Dans sa thèse, Nash présente une situation d’équilibre qui deviendra bientôt l’« équilibre de Nash ». Par équilibre, il entend une situation dans laquelle aucun des joueurs ne peut trouver de meilleure stratégie de jeu, compte tenu des stratégies choisies par les autres joueurs.</p> 
          <p>Prenons l’exemple classique du dilemme du prisonnier. Deux prisonniers (A et B) ont commis un cambriolage. Ils sont interrogés dans des pièces différentes et ne peuvent donc pas tenir compte des réponses de l’autre. i l’un des prisonniers dénonce son complice, il est libre, mais
          son complice est condamné à vingt ans de prison. Si les prisonniers se dénoncent mutuellement, chacun est condamné à dix ans de prison. Enfin, dernier cas, si aucun des deux ne dénonce l’autre, ils écopent tous les deux d’un an de prison.</p>
          
      <Grid container spacing={2} className="something">
        <Grid item xs={12} lg={9}>
          <img src="https://www.iconomix.ch/fileadmin/_processed_/c/b/csm_a006_grafik_bonnie-clyde_fr_9ca80b3875.jpg" 
          width={600} alt="Dilemme du prisonnier"/>
        </Grid>

        <Grid item xs={12} lg={3}>
          <p>A l’équilibre, les prisonniers choisissent de se dénoncer mutuellement car ils n’ont pas la possibilité de coopérer pour obtenir la peine minimale (ils sont dans des cellules séparées). On peut noter que dans ce cas, l’équilibre de Nash n’est pas un optimum de Pareto puisque les deux 
            joueurs pourraient augmenter leur bien-être en coopérant.</p>   
        </Grid>
      </Grid>


      </article>
    </>
  );
}
