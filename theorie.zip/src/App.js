import { CssBaseline } from "@mui/material";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import { Routes, Route } from "react-router-dom";
import { red, yellow, green, blue, purple, grey } from "@mui/material/colors";
import Home from "./pages/Home";
import Exercices from "./pages/Exercices";
import QCMEntrainement from "./pages/QCMEntrainement";
const theme = createTheme({
  palette: {
    primary: {
      main: "#b71c1c",
    },
    secondary: {
      main: grey[500],
    },
    text1: red[500],
    text2: yellow[500],
    text3: green[500],
    text4: blue[500],
    text5: purple[500],
    text6: grey[500],
  },
});

function App() {
  return (
    <>
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/exercices" element={<Exercices />} />
          <Route path="/qcm" element={<QCMEntrainement />} />
        </Routes>
      </ThemeProvider>
    </>
  );
}

export default App;
