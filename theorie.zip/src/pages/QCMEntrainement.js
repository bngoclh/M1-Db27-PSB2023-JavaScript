import NavigationBar from "../components/NavigationBar";
import React, { useState } from "react";
import Matrix1 from "../components/Matrix1";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";
import LinearWithValueLabel from "../components/LinearProgressWithLabel";
import { Button, Divider, Typography } from "@mui/material";
import { QUESTIONS } from "../constants";


export default function Home() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const numberOfQuestions = QUESTIONS.length;
  const [finish, setFinish] = useState(false);
  const [currentAnswers, setCurrentAnswers] = useState(["", "", "", ""]);
  const [showWarning, setShowWarning] = useState(false);

  const allQuestionsAnswered = () => {
    for (let i = 0; i < numberOfQuestions; i++) {
      if (currentAnswers[i] === "") {
        return false;
      }
    }
    return true;
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    // Check answers for all questions and calculate score
    let newScore = 0;
    for (let i = 0; i < numberOfQuestions; i++) {
      if (
        currentAnswers[i] ===
        QUESTIONS[i].answers[QUESTIONS[i].correctAnswerPosition]
      ) {
        newScore++;
      }
    }
    setScore(newScore);
    setFinish(true);
  };

  const handleRadioChange = (event) => {
    const newAnswers = [...currentAnswers];
    newAnswers[currentQuestion] = event.target.value;
    setShowWarning(false);
    setCurrentAnswers(newAnswers);
  };

  const handleNextQuestion = () => {
    if (currentAnswers[currentQuestion] === "") {
      setShowWarning(true);
      return;
    }
    setCurrentQuestion(currentQuestion + 1);
  };

  const handlePreviousQuestion = () => {
    setCurrentQuestion(currentQuestion - 1);
  };
  return (
    <>
      <NavigationBar activePage="QCMEntrainement" />
      {finish && (
        <div>
          <h1>Score: {score}</h1>
        </div>
      )}
      <form onSubmit={handleSubmit}>
        {QUESTIONS.map((question, index) => {
          return (
            <div
              style={{
                display: currentQuestion === index || finish ? "block" : "none",
              }}
            >
              <FormControl sx={{ m: 3 }} variant="standard">
                <FormLabel id="demo-error-radios">
                  <div className="QUESTION 1">
                    <p>{question.subject}</p>
                  </div>
                  <Matrix1></Matrix1>
                </FormLabel>
                <RadioGroup
                  name="quiz"
                  value={currentAnswers[index]}
                  onChange={handleRadioChange}
                >
                  {question.answers.map((answer, index) => {
                    return (
                      <FormControlLabel
                        key={index}
                        value={answer}
                        control={<Radio />}
                        label={
                          <Typography
                            color={
                              finish && index === question.correctAnswerPosition
                                ? "primary"
                                : "default"
                            }
                          >
                            {answer}
                          </Typography>
                        }
                      />
                    );
                  })}
                </RadioGroup>
              </FormControl>
              {finish && (
                <div style={{ marginLeft: 10 }}>
                  <Typography variant="h6">Explanation</Typography>
                  <Typography variant="body2" color="text.secondary">
                    {question.explanation}
                  </Typography>
                  <Divider />
                </div>
              )}
            </div>
          );
        })}
        {showWarning && (
          <Typography variant="body2" color="error">
            Veuillez choisir une réponse.
          </Typography>
        )}
        {!finish && allQuestionsAnswered() && (
          <Button sx={{ mt: 1, mr: 1 }} type="submit" variant="outlined">
            Terminer
          </Button>
        )}
      </form>
      {!finish && (
        <div>
          <Button
            sx={{ mt: 1, mr: 1 }}
            variant="outlined"
            onClick={handlePreviousQuestion}
            disabled={currentQuestion === 0 ? true : false}
          >
            Question précédente
          </Button>
          <Button
            sx={{ mt: 1, mr: 1 }}
            variant="outlined"
            onClick={handleNextQuestion}
            disabled={currentQuestion === numberOfQuestions - 1 ? true : false}
          >
            Question suivante
          </Button>
          <LinearWithValueLabel
            value={(currentQuestion / numberOfQuestions) * 100}
          />
        </div>
      )}
    </>
  );
}
