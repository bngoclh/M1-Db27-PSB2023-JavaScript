// export là để dùng cái component này ở nơi khác//
export const QUESTIONS = [
  {
    subject: "Trouver l'équible de Nash",
    answers: ["Paris", "Lyon", "Marseille", "Toulouse", "Bordeaux"],
    correctAnswerPosition: 0,
    explanation: "Paris est la capitale de la France",

  },
  {
    subject: "2 * 10 = ?",
    answers: ["10", "20", "30", "40", "50"],
    correctAnswerPosition: 1,
    explanation: "you can do math yay",
  },
  {
    subject: "E?",
    answers: ["bruh.", "what", "E.", "đáp án đúng là E (vị trí 3)."],
    correctAnswerPosition: 2,
    explanation: "https://knowyourmeme.com/memes/lord-marquaad-e",
  },
  {
    subject: "What is the best framework?",
    answers: ["React", "Angular", "Vue", "Svelte"],
    correctAnswerPosition: 0,
    explanation: "React is the best framework",
  },
];

export const MATRIXES = {
  matrix1: {
    matrix: [
      [1, 2, 3, 4],
      [2, 4, 6, 8],
      [3, 6, 9, 12],
      [4, 8, 12, 16],
    ],
  },
};
