import NavigationBar from "../components/NavigationBar";

export default function Home() {
  return (
    <>
      <NavigationBar activePage="Exercices" />
    </>
  );
}
